function SwapImage() 
{
	var args = arguments;
	if (args.length == 4)
	{
		var buttonText = GetObjectByID (args[2]);
		buttonText.style.fontWeight = args[3];
	}
	
	document.images[args[0]].src = args[1];
}

function SendButtonClicked()
{
	var args = arguments;
	var button = GetObjectByID (args[0]);
	button.click();
}

function PreloadImages()
{
	var doc = document;
	var args = arguments; 
	if (!doc.imagesArray) 
	{
		doc.imagesArray = new Array();
	}

	for (var i = 0 ; i < args.length ; i++) 
	{ 
		doc.imagesArray[i] = new Image; 
		doc.imagesArray[i].src = args[i];
	}
}

function GetObjectByID (id, obj) 
{
	var children;
	var element;
	var form;
	var elements;
	
	if (!obj) 
	{
		obj = document; 
	}
	
	if (obj.getElementById) 
	{ 
		element = obj.getElementById (id);
	}
	else
	if (obj.layers) 
	{
		children = obj.layers; 
	}
	else 
	if (obj.all) 
	{
		element = obj.all[id]; 
	}
	
	if (element) 
	{ 
		return element;
	}
	
	if (obj.id == id || obj.name == id) 
	{	
		return obj; 
	}
	
	if (obj.childNodes) 
	{
		children = obj.childNodes; 
	}
	
	if (children)
	{
		for (var i = 0 ; i < children.length; i++) 
		{
			element = GetObjectByID (id, children[i]); 
			if (element) 
			{
				return element; 
			}
		}
		
		form = obj.forms; 
		if (form) 
		{
			for (i = 0 ; i < form.length ; i++) 
			{
				elements = form[i].elements;
				for (var j = 0 ; j < elements.length ; j++)
				{ 
					element = GetObjectByID (id, elements[i]); 
					if (element)
					{
						return element; 
					}
				}
			}
		}
	}
	
	return null;
}